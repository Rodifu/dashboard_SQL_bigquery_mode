# Starbucks SQL Analytics (Mode / BigQuery)

This repository contains a collection of SQL queries used to analyze Starbucks performance data, including revenue metrics, gross margin, customer retention, churn analysis, product profitability, and forecasting trends.

All queries were developed for use in **Mode Analytics** and **BigQuery**, following best practices for analytical SQL.

---

## 📁 Repository Structure

```text
queries/
   average_order_value.sql
   gross_margin_pct.sql
   total_revenue_yoy_growth.sql
   profitability_trend.sql
   percentile_trend.sql
   customer_retention_overall.sql
   sales_by_category_profit_margin_per_product.sql
   country_performance.sql
   sales_channel_distribution.sql
   customers_churn_retention_overview.sql
   customers_churn_retention_online.sql
   forecast_ml_profitability.sql
README.md
```

---

## 📊 Query Overview

### average_order_value.sql
Calculates the **Average Order Value (AOV)** based on aggregated revenue per order.

### gross_margin_pct.sql
Computes the **Gross Margin Percentage**, using total revenue and cost.

### total_revenue_yoy_growth.sql
Returns:
- Total Revenue  
- Revenue from the previous year  
- Revenue from the current year  
- **Year-over-Year (YoY) Growth**

### profitability_trend.sql
Generates a monthly trend of:
- Gross Margin  
- Total Revenue  
- Total Cost  

### percentile_trend.sql
Calculates AOV distribution metrics by month:
- Mean AOV  
- AOV P50  
- AOV P90  

### customer_retention_overall.sql
Computes overall **customer retention rate**, used for high-level KPIs.

### sales_by_category_profit_margin_per_product.sql
Summarizes:
- Total revenue by product category  
- Gross profit per category  

### country_performance.sql
Breakdown of:
- Revenue by country  
- Gross profit by country  

### sales_channel_distribution.sql
Shows revenue distribution by sales channel (Online, In-Store, etc.) over time.

### customers_churn_retention_overview.sql
Provides a monthly overview of:
- Active customers  
- Retained customers  
- Lost customers  
- Retention rate  
- Churn rate  

### customers_churn_retention_online.sql
Same metrics as above, but **filtered exclusively for online customers**.

### forecast_ml_profitability.sql
Forecast-based profitability analysis containing:
- Predicted revenue  
- Predicted cost  
- Forecasted gross margin  

---

## 🧠 Technologies Used

- **BigQuery SQL**
- **Mode Analytics**
- Date and time functions (FORMAT_DATE, DATE_TRUNC)
- Analytical functions (PERCENTILE_CONT, SAFE_DIVIDE)
- Window functions
- Common Table Expressions (CTEs)

---

## 🚀 How to Use

Clone the repository:

```bash
git clone https://github.com/your-username/starbucks-sql-analytics.git
cd starbucks-sql-analytics
```

Run the queries in:
- **Mode Analytics SQL Editor**, or
- **Google BigQuery Console**

Ensure your dataset references match your BigQuery project path.

---
